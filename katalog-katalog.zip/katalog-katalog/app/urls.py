from django.urls import path

from . import views

urlpatterns  = [
    path('', views.index, name='index'),
    path('product-details/<int:id>/', views.product_details, name='product_details'),
    path('store-details/<int:id>/', views.store_details, name='store_details'),
    path('stores', views.stores, name='stores'),
    path('<int:id>/total', views.total, name='total')
]
