from django.db import models

# Create your models here.
from django.http import HttpResponse


class Product(models.Model):
    name = models.CharField(max_length=255,default='2')
    type = models.CharField(max_length=255)
    logo = models.CharField(max_length=255)



class Store(models.Model):
    name = models.CharField(max_length=254)
    address = models.CharField(max_length=255)
    logo = models.CharField(max_length=255)


class ProductStore(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    store = models.ForeignKey(Store, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    price = models.IntegerField()
    # def line_total(self):
    #      return self.quantity,self.price

from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver


class Profil(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    produktet = models.ManyToManyField(ProductStore)

    @receiver(post_save, sender=User)
    def create_user_profile(sender, instance, created, **kwargs):
        if created:
            Profil.objects.create(user=instance)

    @receiver(post_save, sender=User)
    def save_user_profile(sender, instance, **kwargs):
        instance.profil.save()