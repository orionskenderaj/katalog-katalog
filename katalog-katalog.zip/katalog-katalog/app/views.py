# Create your views here.
from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from app.models import Product, Store, ProductStore


@login_required(login_url='/accounts/login/')
def index(request):
    products = Product.objects.all()
    data = {'products': products}
    return render(request, 'index.html', data)


def product_details(request, id):
    product = Product.objects.get(id=id)
    store_ids = ProductStore.objects.filter(product_id=id).values_list('store_id', flat=True)
    stores_having_product_id = Store.objects.filter(id__in=store_ids)
    data = {'stores': stores_having_product_id,'product':product}
    return render(request, 'product_details.html', data)
def store_details(request, id):
    store = Store.objects.get(id=id)
    product_ids = ProductStore.objects.filter(store_id=id).values_list('product_id', flat=True)
    product_stores = ProductStore.objects.filter(store_id=id)
    products = Product.objects.filter(id__in=product_ids)
    data = {'store': store, 'products':products, 'stps':product_stores}
    return render(request, 'store_details.html', data)
def stores(request):
    store_det=Store.objects.all()
    data ={'store_det': store_det}
    return render (request,'Stores.html',data)
def total(request,id):

    produkte=ProductStore.objects.filter(id=id)
    shuma=0
    for produkt in produkte:
        shuma = shuma + (produkt.quantity * produkt.price)
        data={'emri': produkt.store.name,"logo":produkt.store.logo,'adresa':produkt.store.address,
             'totali':shuma}
    return render(request,'inventar.html',data)




