import csv

from app.models import Product, Store, ProductStore


def create_product(name, type, logo):
    product = Product(name =name, type =type, logo =logo)
    product.save()
    return product


def create_store(name, address, logo):
    store = Store(name=name, address=address, logo=logo)
    store.save()
    return store


def create_productstore(product, store, quantity, price):
    product_store = ProductStore(product=product, store=store, quantity=quantity, price=price).save()


def insert_products_to_db():
    with open('products.csv', 'r') as data:
        reader = csv.reader(data)
        for line in reader:
            # create product by checking if it already exists
            if Product is None:
                product = create_product(name=line[0], type=line[1], logo=line[2])
            else:
                try:
                    product = Product.objects.get(name=line[0])
                except Product.DoesNotExist:
                    product = create_product(name=line[0], type=line[1], logo=line[2])
            # create store by checking if it already exists
            if Store is None:
                store = create_store(name=line[5], address=line[6], logo=line[7])
            else:
                try:
                    store = Store.objects.get(name=line[5], address=line[6])
                except Store.DoesNotExist:
                    store = create_store(name=line[5], address=line[6], logo=line[7])
                    # create product_store table
            create_productstore(store=store, product=product, quantity=line[3], price=line[4])


def run():
    insert_products_to_db()
